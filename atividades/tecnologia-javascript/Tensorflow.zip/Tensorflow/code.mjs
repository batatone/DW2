import * as tf from '@tensorflow/tfjs';

// Crio um modelo pra regressão linear
const model = tf.sequential();
model.add(tf.layers.dense({units: 1, inputShape: [1]}));

// Preparo o modelo pra treinamento escolhendo uma função de otimização e uma de validação.
model.compile({loss: 'meanSquaredError', optimizer: 'sgd'});

// Criamos dados para que ele possa treinar
const input = tf.tensor2d([ 0, 1, 2, 3, 4,  5], [6, 1]);
const response = tf.tensor2d([ 1, 3, 5, 7, 9, 11], [6, 1]);

// Treinamos o modelo com os dados que criamos

model.fit(input, response, { epochs: 1000 }).then(() => {
  // E agora podemos pedir para que o modelo preveja o 
  // resultado de um input que não estava no set de treinamento
  model.predict(tf.tensor2d([6], [1, 1])).print()
});